import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "./App.css";
import { supabase } from "./supabase";

const CATS = [
  { id: "restaurant", label: "Restaurants", emoji: "🍽️", color: "#E24B4A" },
  { id: "cafe",       label: "Cafes",        emoji: "☕",  color: "#BA7517" },
  { id: "fastfood",   label: "Fast Food",    emoji: "🍔", color: "#3B6D11" },
  { id: "halal",      label: "Halal",        emoji: "🌙", color: "#185FA5" },
  { id: "vegan",      label: "Vegan/Veg",    emoji: "🥦", color: "#1D9E75" },
  { id: "bubble",     label: "Bubble Tea",   emoji: "🧋", color: "#993556" },
];

function makeIcon(cat, active) {
  const size = active ? 42 : 34;
  return L.divIcon({
    className: "",
    html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${cat.color};border:3px solid white;display:flex;align-items:center;justify-content:center;font-size:${active ? 19 : 16}px;box-shadow:0 2px 10px rgba(0,0,0,0.25);">${cat.emoji}</div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2 - 4],
  });
}

function FlyTo({ place }) {
  const map = useMap();
  if (place) map.flyTo([place.lat, place.lng], 17, { duration: 1 });
  return null;
}

export default function App() {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilters, setActiveFilters] = useState(new Set());
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  // Load places from Supabase on startup
  useEffect(() => {
    async function loadPlaces() {
      const { data, error } = await supabase
        .from("places")
        .select("*")
        .eq("visible", true);
      if (error) {
        console.error("Error loading places:", error);
      } else {
        setPlaces(data);
      }
      setLoading(false);
    }
    loadPlaces();
  }, []);

  const catFor = (id) => CATS.find((c) => c.id === id) || CATS[0];

  const visible = places.filter((p) => {
    const catMatch = activeFilters.size === 0 || activeFilters.has(p.category);
    const q = search.toLowerCase();
    const nameMatch = !q || p.name.toLowerCase().includes(q) || (p.building || "").toLowerCase().includes(q);
    return catMatch && nameMatch;
  });

  const toggleFilter = (id) => {
    setActiveFilters((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const selectPlace = (p) => setSelected(selected?.id === p.id ? null : p);

  return (
    <div className="app">
      {/* HEADER */}
      <header className="header">
        <div className="logo">UofT<span>Eats</span></div>
        <input
          className="search"
          type="text"
          placeholder="Search places, buildings..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </header>

      <div className="main">
        {/* SIDEBAR */}
        <aside className="sidebar">
          <div className="res-header">
            {loading ? "Loading..." : `${visible.length} places near UofT`}
          </div>
          <div className="place-list">
            {loading ? (
              <div className="loading-msg">Loading places from database...</div>
            ) : (
              visible.map((p) => {
                const cat = catFor(p.category);
                return (
                  <div
                    key={p.id}
                    className={`place-item ${selected?.id === p.id ? "active" : ""}`}
                    onClick={() => selectPlace(p)}
                  >
                    <div className="place-ico" style={{ background: cat.color + "22" }}>
                      {cat.emoji}
                    </div>
                    <div className="place-info">
                      <div className="place-name">{p.name}</div>
                      <div className="place-sub">{cat.label}</div>
                      <div className="place-building">{p.building}</div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </aside>

        {/* MAP */}
        <div className="map-wrap">
          <MapContainer
            center={[43.6629, -79.3957]}
            zoom={15}
            style={{ width: "100%", height: "100%" }}
          >
            <TileLayer
              attribution='© <a href="https://openstreetmap.org">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <FlyTo place={selected} />
            {visible.map((p) => {
              const cat = catFor(p.category);
              const isActive = selected?.id === p.id;
              return (
                <Marker
                  key={p.id}
                  position={[p.lat, p.lng]}
                  icon={makeIcon(cat, isActive)}
                  eventHandlers={{ click: () => selectPlace(p) }}
                >
                  <Popup>
                    <strong style={{ fontSize: 14 }}>{p.name}</strong><br />
                    <span style={{ color: "#888", fontSize: 12 }}>{cat.emoji} {cat.label}</span><br />
                    <span style={{ color: "#aaa", fontSize: 11 }}>📍 {p.building}</span><br />
                    <span style={{ fontSize: 12, color: "#555" }}>{p.description}</span>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>

          {/* FILTER BAR */}
          <div className="filter-bar">
            <span className="filter-lbl">Filters</span>
            {CATS.map((c) => (
              <button
                key={c.id}
                className={`fp ${activeFilters.has(c.id) ? "on" : ""}`}
                style={activeFilters.has(c.id) ? { background: c.color, borderColor: c.color } : {}}
                onClick={() => toggleFilter(c.id)}
              >
                {c.emoji} {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
